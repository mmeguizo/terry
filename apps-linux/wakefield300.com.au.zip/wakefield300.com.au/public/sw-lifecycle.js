// Placeholder to prevent 404 requests for sw-lifecycle.js
(function(){ /* no-op */ })();
